//Henrique Pires Aragão 21304445
public class TestAlea {
    public static void main(String[] args){
        System.out.println(Alea.chaine()); //Il faut prefixer pour acceder la methode
        // Alea a = new Alea();
        //La ligne de code ci-dessus provoque une erreur; 
    }
}
