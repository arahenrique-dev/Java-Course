package exo5;

public class Bonjour {
    public static void main(String[] arg) {
        System.out.println("Bonjour !");
        //C'est la commande : java Bonjour.java
    }
    
}